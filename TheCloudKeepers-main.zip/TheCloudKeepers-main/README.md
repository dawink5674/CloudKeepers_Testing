# TheCloudKeepers

Honey-Lambda: a serverless honeypot and threat-intel platform.